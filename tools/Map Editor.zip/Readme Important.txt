This will not work if you dont have san andreas multiplayer and gta sa
move the files to gta sa folder to make it work