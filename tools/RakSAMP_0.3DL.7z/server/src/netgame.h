/*
	Updated to 0.3.7 by P3ti
*/

void resetPools();
void UpdateNetwork();
void UpdatePosition(int iPlayerID, float fX, float fY, float fZ);
