/*
	Updated to 0.3.7 by P3ti
*/

void RegisterServerRPCs(RakServerInterface *pRakServer);
void UnRegisterServerRPCs(RakServerInterface * pRakServer);
