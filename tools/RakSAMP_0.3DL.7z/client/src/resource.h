#define IDI_MAIN 100

#define IDD_DIALOGS 200
