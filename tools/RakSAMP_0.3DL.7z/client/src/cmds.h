/*
	Updated to 0.3.7 by P3ti
*/

int RunCommand(char *szCMD, int iFromAutorun);
