GameTextFix
===========

A Small library that provides a fix for buggy SA-MP GameText Styles.
