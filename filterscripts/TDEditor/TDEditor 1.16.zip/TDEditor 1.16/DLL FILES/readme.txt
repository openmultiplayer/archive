Copy all .dll files to your server folder if you get missing MSV---.dll file error.

Thanks you for download TDEditor 1.16 Update. Sorry for my behavior. Have fun.