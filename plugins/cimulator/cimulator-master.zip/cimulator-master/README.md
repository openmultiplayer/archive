# cimulator
Collision detection and Physics simulation for SanAndreas Multiplayer

A proper readme is provided in the download zip file.
